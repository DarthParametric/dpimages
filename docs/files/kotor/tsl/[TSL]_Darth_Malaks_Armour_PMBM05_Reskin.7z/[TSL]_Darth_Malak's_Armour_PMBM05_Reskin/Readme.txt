Knights of the Old Republic II: The Sith Lords

DARTH MALAK'S ARMOUR - PMBM05/PFBM05 RESKIN
===========================================


AUTHOR:
DarthParametric


ABOUT:
I started another TSL play through recently. I hadn't done any modding for some time, but
while playing I got the urge to fix something that has always bugged me. Namely, that the
supposed armour of Darth Malak that is included in the game as one of the PC-wearable
armoured robes doesn't actually look anything like what Malak wore in the first game. So
I decided to have a crack at a reskin. The armour is the same for both males and females,
and I have included textures for both.


INSTRUCTIONS:
Extract the archive and drop a copy of pmbm05.tga and pfbm05.tga in your Override folder.
To uninstall, simply delete both files.


COMPATIBILITY:
Obviously, this mod won't be compatible with any other mod that employs an edited version
of pmbm05.tga/pfbm05.tga. Changes to the PMBMM/PFBMM models may also be problematic (although
I'm unaware of any mod that does this).


BUGS:
There are some minor quirks due to the way the armour mesh is modelled and UV mapped. Despite
being a freaky giant, Malak has quite a svelte figure with narrow hips. The TSL armour mesh
on the other hand has fairly broad hips with a pronounced inner thigh gap. I'm not sure if
this is deliberate choice due to the mesh being unisex, or just an artistic decision the
modeller made. Either way, the groin area where the legs attach is a bit funky, and coupled
with the usual god-awful default UV maps of KOTOR meshes the result isn't the best. I'm too
lazy to do anything about it like altering the mesh or UV map though. The model also has a
leg pouch and some chest pipes which I've simply camouflaged. I could have removed them by
editing the mesh and UV map, but again I'm lazy. Also, because of the way the engine works,
you probably aren't going to see much detail at higher screen resolutions. It will probably
look like your PC/party member is running around in a plain orange jumpsuit. You will see
more detail in a few cutscenes though.

Finally, all the usual funkiness with that series of armoured robes that Obsidian added to
the game also still applies - temperamental "skirt" animations, gimped hand helpers, various
clipping issues.


CONTACT:
You can PM me at LucasForums - http://www.lucasforums.com/member.php?u=108447


PERMISSIONS:
This mod may not be altered or distributed on other sites without the express permission of
the author.


DISCLAIMER:
This modification is provided as-is and is not supported by Bioware, Obsidian Entertainment,
LucasArts or their licensers/sponsors. Use of this file is at your own risk. Neither the
aforementioned companies or the author/s are responsible for any damage that may be caused
to your computer by the usage of this file.

Star Wars, Knights of the Old Republic and related properties are trademarks of Lucasfilm
Ltd. and/or its affiliates. Bioware and the Odyssey Engine are trademarks of Bioware Corp.
Obsidian Entertainment is a trademark of Obsidian Entertainment, Inc.