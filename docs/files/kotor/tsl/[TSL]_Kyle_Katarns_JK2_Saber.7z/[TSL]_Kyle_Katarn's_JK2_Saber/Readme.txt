Knights of the Old Republic II: The Sith Lords

KYLE KATARN'S JK2 LIGHTSABER
============================


AUTHOR:
DarthParametric


ABOUT:
This is Kyle Katarn's lightsaber from Jedi Knight II: Jedi Outcast (and also JK3: Jedi Academy).
It's a large and imposing single bladed hilt. Although inspired by the JK2 original, this is a
completely new mesh and texture made by me - not a port.

The hilt has the following base stats:

     Damage:            Energy, 2-20
     Critical Threat:   17-20,x2
     Attack Modifier:   +2
     Defense Bonus:     2

The saber is upgradeable and comes with a custom colour crystal.


INSTRUCTIONS:
Extract the archive and run TSLPatcher.exe. Follow the program's instructions to install the mod.
Place the items in your inventory via KSE or console command. The hilt is g_w_lghtsbr58 and the
crystal is u_l_colo_58.


COMPATIBILITY:
The hilt and crystal both use ModelVariation 58. They will not be compatible with any other saber
mod that uses custom crystals/hilts with this value. Aside from that, it should be compatible with
pretty much any other saber mod that uses TSLPatcher. If you have an older mod that comes with a
pre-edited upcrystals.2da you MUST install that mod first. This mod will then patch upcrystals.2da
with the Katarn saber data. As far as I can tell it should be compatible with the Ultimate Saber Mod,
but make sure you install USM first!
 

BUGS:
Because of the limitations of the available tools, the blade glow extends somewhat past the emitter.
This is merely an aesthetic issue and I doubt most people will notice or be concerned by it. Because
it is only of minor consequence for this hilt, I decided to release it as-is. I am investigating
avenues to resolve this for other hilts where is it more crucial, so I may release a revised version
of this hilt at some point in the future that fixes the problem, should that prove possible.


ACKNOWLEDGEMENTS:
Thanks goes to ChAiNz.2da for help during my early attempts at converting my hilts into game-ready
meshes and the resultant struggles with MDLOps and GMax. Special thanks to sv�sh for ongoing help
in tackling the thorny issue of altering the position of blade planes.


CONTACT:
You can contact me via the SWKnights forums - http://www.lucasforums.com/member.php?u=108447


PERMISSIONS:
This mod may not be altered or distributed on other sites without the express permission of
the author.


DISCLAIMER:
This modification is provided as-is and is not supported by Bioware, Obsidian Entertainment,
LucasArts or their licensers/sponsors. Use of this file is at your own risk. Neither the
aforementioned companies or the author/s are responsible for any damage that may be caused
to your computer by the usage of this file.

Star Wars, Knights of the Old Republic and related properties are trademarks of Lucasfilm Ltd.
and/or its affiliates. Bioware and the Odyssey Engine are trademarks of Bioware Corp. Obsidian
Entertainment is a trademark of Obsidian Entertainment, Inc.