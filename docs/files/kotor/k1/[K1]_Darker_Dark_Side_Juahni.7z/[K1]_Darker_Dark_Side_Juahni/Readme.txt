Knights of the Old Republic

DARKER DARK SIDE JUHANI
============================


AUTHOR:
DarthParametric


ABOUT:
This is a reskin of Juhani when you first encounter her on Dantooine. 

As part of your Jedi trials, you are sent to cleanse the Grove of its taint. When you arrive at
the Grove, you discover that the taint is Juhani, a Jedi who has fallen to the Dark Side after
apparently slaying her master in anger. Although Dark Juhani has a red lightsaber, she doesn't
have the other essential Dark Jedi accoutrements - black duds! You can't effectively channel
the Dark Side of the Force wearing blue and brown! As well as a change in colour, I felt dipping
her toes in the Dark Side might also free up some of those Jedi inhibitions, so she's showing a
little bit more skin (fur?) than usual.


INSTRUCTIONS:
Extract the archive and run TSLPatcher.exe. Follow the program's instructions to install the mod.
To uninstall, either delete dan14_juhani.utc from your Override folder or replace it with the backup
TSLPatcher made (if you had a pre-existing Juhani mod).

If you would prefer to have Juhani also use the skin for her default clothes after she joins your
party then you can skip using TSLPatcher and simply copy the TGA and TXI files into your Override
folder. Rename them P_JuhaniBB01.tga and P_JuhaniBB01.txi respectively. To uninstall simply delete
both files.


COMPATIBILITY:
If you have any older mods that put a pre-modified appearence.2da in the Override folder you MUST
install them first. This mod will then patch that file. This mod should be compatible with other
Juhani mods, but be aware that it will override any change to her clothes in the Grove. Changes to
the in-party Juhani will be unaffected. It should be compatible with WOTOR, but WOTOR must be
installed first. This mod will then patch the UTC file.


BUGS:
None that I am aware of.


CONTACT:
You can PM me at LucasForums - http://www.lucasforums.com/member.php?u=108447


PERMISSIONS:
This mod may not be altered or distributed on other sites without the express permission of
the author.


DISCLAIMER:
This modification is provided as-is and is not supported by Bioware, Obsidian Entertainment,
LucasArts or their licensers/sponsors. Use of this file is at your own risk. Neither the
aforementioned companies or the author/s are responsible for any damage that may be caused
to your computer by the usage of this file.

Star Wars, Knights of the Old Republic and related properties are trademarks of Lucasfilm Ltd.
and/or its affiliates. Bioware and the Odyssey Engine are trademarks of Bioware Corp. Obsidian
Entertainment is a trademark of Obsidian Entertainment, Inc.