Knights of the Old Republic

KYLE KATARN'S JK2 LIGHTSABER
============================


AUTHOR:
DarthParametric


ABOUT:
This is Kyle Katarn's lightsaber from Jedi Knight II: Jedi Outcast (and also JK3: Jedi Academy).
It's a large and imposing single bladed hilt. Although inspired by the JK2 original, this is a
completely new mesh and texture made by me - not a port.

The hilt has the following base stats:

     Damage:            Energy, 2-16
     Critical Threat:   17-20,x2
     Attack Modifier:   +2
     Defense Bonus:     2

The saber is upgradeable and comes with a custom colour crystal.


INSTRUCTIONS:
Extract the archive and run TSLPatcher.exe. Follow the program's instructions to install the mod.
Place the items in your inventory via KSE or console command. The hilt is g_w_lghtsbr28 and the
crystal is g_w_sbrcrstl28.


COMPATIBILITY:
The hilt and crystal both use ModelVariation 28. They will not be compatible with any other saber
mod that uses custom crystals/hilts with this value. Aside from that, it should be compatible with
pretty much any other saber mod that uses TSLPatcher. If you have an older mod that comes with a
pre-edited upcrystals.2da you MUST install that mod first. This mod will then patch upcrystals.2da
with the Katarn saber data. It should be compatible with Weapons of the Old Republic.
 

BUGS:
There is some minor clipping occasionally with the hand holding the hilt. This varies depending
on the sex of the wielder (mostly left hand for males, right hand for females) and the
armour/robes/clothes being worn. It invariably occurs when dual wielding. Basically the model's
hand helpers that tell the game where to position the hand are gimped in a lot of cases and the
only way to avoid clipping altogether is to scale the hilt down to the size of a pencil. I've
endeavoured to keep the clipping relatively minor whilst still retaining the proportions of the
original hilt it is modelled after.


ACKNOWLEDGEMENTS:
Thanks goes to ChAiNz.2da for help during my early attempts at converting my hilts into game-ready
meshes and the resultant struggles with MDLOps and GMax. Special thanks to sv�sh for ongoing help
in tackling the thorny issue of altering the position of blade planes.


CONTACT:
You can contact me via the SWKnights forums - http://www.lucasforums.com/member.php?u=108447


PERMISSIONS:
This mod may not be altered or distributed on other sites without the express permission of
the author.


DISCLAIMER:
This modification is provided as-is and is not supported by Bioware, Obsidian Entertainment,
LucasArts or their licensers/sponsors. Use of this file is at your own risk. Neither the
aforementioned companies or the author/s are responsible for any damage that may be caused
to your computer by the usage of this file.

Star Wars, Knights of the Old Republic and related properties are trademarks of Lucasfilm Ltd.
and/or its affiliates. Bioware and the Odyssey Engine are trademarks of Bioware Corp. Obsidian
Entertainment is a trademark of Obsidian Entertainment, Inc.