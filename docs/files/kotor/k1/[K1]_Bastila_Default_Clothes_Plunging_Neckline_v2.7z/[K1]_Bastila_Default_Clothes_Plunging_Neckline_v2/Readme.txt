Knights of the Old Republic

BASTILA DEFAULT CLOTHES - PLUNGING NECKLINE & HOTPANTS
======================================================


AUTHOR:
DarthParametric


ABOUT:
This is a reskin of Bastila's default clothes to give her a plunging neckline and hotpants.
There are two versions, one a bit more extreme than the other.


INSTRUCTIONS:
Extract the archive and copy your preferred version of p_bastilabb01.tga into your Override
folder. To uninstall, simply delete p_bastilabb01.tga.


COMPATIBILITY:
Obviously, this mod won't be compatible with any other mod that employs an edited version
of p_bastilabb01.tga.


BUGS:
None that I am aware of.


CONTACT:
You can PM me at LucasForums - http://www.lucasforums.com/member.php?u=108447


PERMISSIONS:
This mod may not be altered or distributed on other sites without the express permission of
the author.


DISCLAIMER:
This modification is provided as-is and is not supported by Bioware, Obsidian Entertainment,
LucasArts or their licensers/sponsors. Use of this file is at your own risk. Neither the
aforementioned companies or the author/s are responsible for any damage that may be caused
to your computer by the usage of this file.

Star Wars, Knights of the Old Republic and related properties are trademarks of Lucasfilm
Ltd. and/or its affiliates. Bioware and the Odyssey Engine are trademarks of Bioware Corp.
Obsidian Entertainment is a trademark of Obsidian Entertainment, Inc.