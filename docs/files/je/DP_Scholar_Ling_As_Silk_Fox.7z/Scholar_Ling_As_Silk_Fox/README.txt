Jade Empire: Special Edition

SCHOLAR LING AS SILK FOX
=========================

AUTHOR:
DarthParametric

ABOUT:
This mod replaces Silk Fox's default model and portraits with those for
Scholar Ling, normally a female PC character. The portraits are custom
ones derived from wallpaper images made by Bioware. This mod is a
variation on my original Dawn Star replacement mods available here: 

https://dpmods.bg2redux.com/jade_empire.html

INSTALLATION:
Copy the CRE and TGA files in the archive's Override folder to the Override
folder in your JE installation directory. You must also delete the following
TXB files in your JE Override folder:

ui_ph_silk.txb
ui_ph_silkd.txb
ui_ph_silke.txb
ui_ph_silkg.txb
ui_ph_silkq.txb

These are Sild Fox's default portraits. If you don't delete these, they
will supersede the replacement TGAs and you won't get the custom
Ling portraits. 

UNINSTALLATION:
Delete the CRE and TGA files from the JE Override folder. Copy the
backup TXB files in the ORIGINAL PORTRAITS folder to your JE
Override directory.

KNOWN ISSUES:
This mod was a request and has not been tested at the time of writing.
However, based on the previous Dawn Star mods, there is likely to be
some occasional minor clipping of the mouth box through the cheeks
during some lip sync animations, and possibly other distortions like
bug eyes.

ACKNOWLEDGEMENTS:
Thanks to stoffe and tk102 for providing the tools that allow mods like
this to be made.


CONTACT:
You can contact me via the SWKnights forums:
 
http://www.lucasforums.com/member.php?u=108447


PERMISSIONS:
This mod may not be altered or distributed on other sites without the
express permission of the author.


DISCLAIMER:
This modification is provided as-is and is not supported or sanctioned by
Bioware, Gray Matter, or 2K. Use of this file is at your own risk. Neither
the aforementioned companies or the author/s are responsible for any
damage that may be caused to your computer by the usage of this file.