Jade Empire: Special Edition

WU THE LOTUS BLOSSOM AS DAWN STAR
=================================

AUTHOR:
DarthParametric

ABOUT:
This mod replaces Dawn Star's default model and portraits with those for Wu the Lotus
Blossom, normally a female PC character. The portraits are custom ones derived from Wu
wallpaper images made by Bioware.

INSTALLATION:
Copy the CRE and TGA files in the archive's Override folder to the Override folder in your
JE installation directory. You must also delete the following TXB files in your JE Override
folder:

ui_ph_dawn.txb
ui_ph_dawnd.txb
ui_ph_dawne.txb
ui_ph_dawng.txb
ui_ph_dawnq.txb

These are Dawn Star's default portraits. If you don't delete these, they will supersede the
replacement TGAs and you won't get the custom Wu portraits. 

UNINSTALLATION:
Delete the CRE and TGA files from the JE Override folder. Copy the backup TXB files in the
ORIGINAL PORTRAITS folder to your JE Override directory.

KNOWN ISSUES:
While there doesn't seem to be any major issues, there is occasionally some minor clipping of
the mouth box through the left cheek during some lip sync animations. She also seems to have a
tendency to be extremely wide-eyed in a lot of the cutscenes. Perhaps she is just surprised at
her hot new body. ;) Obviously, the pre-rendered cutscenes will still use the original Dawn Star
model.

ACKNOWLEDGEMENTS:
Thanks to stoffe and tk102 for providing the tools that allow mods like this to be made.


CONTACT:
You can contact me via the SWKnights forums - http://www.lucasforums.com/member.php?u=108447


PERMISSIONS:
This mod may not be altered or distributed on other sites without the express permission of
the author.


DISCLAIMER:
This modification is provided as-is and is not supported or sanctioned by Bioware, Gray Matter,
or 2K. Use of this file is at your own risk. Neither the aforementioned companies or the author/s
are responsible for any damage that may be caused to your computer by the usage of this file.